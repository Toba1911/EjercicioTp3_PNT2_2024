// services/axios.js
import axios from 'axios';

const axiosInstance = axios.create({
  baseURL: 'https://66663bb1a2f8516ff7a2e4b0.mockapi.io',
  // Aquí puedes añadir más configuraciones como headers por defecto
});

export default axiosInstance;
