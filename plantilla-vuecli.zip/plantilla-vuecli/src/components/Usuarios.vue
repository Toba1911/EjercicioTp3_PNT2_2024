<template>

  <section class="src-componentes-respuestas">
    <div class="jumbotron">
      <h2>Usuarios</h2>
      <br>

      <div class="table-responsive">
        <table class="table table-dark">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Email</th>
              <th>Teléfono</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="user in users" :key="user.id">
              <td>{{ user.name }}</td>
              <td>{{ user.email }}</td>
              <td>{{ user.phone }}</td>
            </tr>
          </tbody>
        </table>
      </div>      

    </div>
  </section>

</template>

<script>
import { getUsers } from '@/Users';

export default {
  name: 'Usuarios',
  data() {
    return {
      users: []
    };
  },
  mounted() {
    getUsers()
      .then(response => {
        this.users = response.data;
      })
      .catch(error => {
        console.error('Error fetching users:', error);
      });
  }
  
};
</script>

<style scoped lang="css">
  .src-components-respuestas {
    padding: 20px;
  }
</style>
